const basesdatos = require("mysql");

const conexion_db = basesdatos.createConnection({
    host: "localHost",
    user: "root",
    password:"",
    database: "mi_database"
});

conexion_db.connect((err) =>{
    if(err){
        console.log(err);
    }
    else{
        console.log("conectado satisfactoriamente")

        /*
        conexion_db.query("SELECT * FROM `usuario` WHERE 1", (err,resultado)=> {
            if(err)
            {
                console.log(err);
            }
            else
            {
                console.log(resultado[1].nombre)

            }
        });*/

        /*
        conexion_db.query("INSERT INTO `usuario` (`nombre`, `edad`, `direccion`) VALUES ('Carlos', '32', 'Ramon Rayon, Palacio de Mitla 34567');", (err,resultado)=> {
            if(err)
            {
                console.log(err);
            }
            else
            {
                console.log(resultado)

            }
        });
        */

        /*
        var numeroID = 4;
        conexion_db.query("SELECT * FROM `usuario` WHERE id = "+ numeroID, (err,resultado)=> {
            if(err)
            {
                console.log(err);
            }
            else
            {
                console.log(resultado)

            }
        });
        */

        /*conexion_db.query("UPDATE `usuario` SET nombre=('Pepe'), edad=(0) WHERE id = 1", (err,resultado)=> {
            if(err)
            {
                console.log(err);
            }
            else
            {
                console.log(resultado)

            }
        });*/

        conexion_db.query("DELETE from `usuario` WHERE id = 4", (err,resultado)=> {
            if(err)
            {
                console.log(err);
            }
            else
            {
                console.log(resultado)

            }
        });
        conexion_db.end();
    }
});